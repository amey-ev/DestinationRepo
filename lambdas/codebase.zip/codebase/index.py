# print("Hello World This is CodeBase")
print("This  is Sync Repo")